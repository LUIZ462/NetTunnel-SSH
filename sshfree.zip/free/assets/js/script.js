const menu = document.getElementById("menu");
const header = document.querySelector("header");
const logo = document.querySelector("header .logo a");
const iconx = document.querySelector(".menu_button a i");
const menuBtns = document.querySelectorAll("header .menu li a");
const menu_device = document.querySelector("#menu_toggle");
const menuToggleLi = document.querySelectorAll("#menu_toggle li a");


const icon = document.getElementById("icon");
const menuToggle = document.getElementById("menu_toggle");
const subdomain = document.getElementById("subdominio");
const prices = document.getElementById("planos");

menu.addEventListener("click", function(e){
	e.preventDefault();
    if (menuToggle.classList.contains('open')) {
    	menuToggle.classList.add("close");
        menuToggle.classList.remove("open");
        setInterval(function(){
        	menuToggle.classList.remove("close");
        }, 300);
        icon.classList.remove("fa-times");
        icon.classList.add("fa-bars");
    } else {
        icon.classList.remove("fa-bars");
        icon.classList.add("fa-times");
        menuToggle.classList.remove("close");
        menuToggle.classList.add("open");
    }
});
if(prices){
prices.addEventListener("click", function(){
        menuToggle.classList.remove("open");
        icon.classList.remove("fa-times");
        icon.classList.add("fa-bars");
});


subdomain.addEventListener("click", function(){
        menuToggle.classList.add("close");
        menuToggle.classList.remove("open");
        icon.classList.remove("fa-times");
        icon.classList.add("fa-bars");
});
}
function toggleMenu(){
    menuToggle.classList.add("close");
    setInterval(function(){
        menuToggle.classList.remove("close");
    }, 300);
    menuToggle.classList.remove("open");
    icon.classList.remove("fa-times");
    icon.classList.add("fa-bars");
}
    
    window.onload = setTimeout(function removeElement() {
    var element = document.getElementById("loader");
    element.parentNode.removeChild(element);
}, 500);

const plans = document.querySelectorAll(".collection .plano");

for(let i = 0; i < plans.length; i++){
    ScrollReveal().reveal(plans[i], {
        delay: i * 200,
        duration: i * 500,
        reset: true,
        easing: 'ease-in'
    });
}

const sites = document.querySelectorAll(".sites .item");

for(let i = 0; i < sites.length; i++){
    ScrollReveal().reveal(sites[i], {
        delay: i * 50,
        duration: i * 200,
        reset: true,
        origin: i % 2 == 0 ? 'left' : 'rigth',
        easing: 'linear',
        distance: "20px"
    });
}


function visitSite(url){
    setTimeout(function(){
        window.open("https://" + url);
    }, 300)
    
}



window.addEventListener("scroll", (event) => {
    let scroll = this.scrollY;
    tempo = 100;
    if(scroll > 300){
        header.style.backgroundColor = "#fff";
        iconx.style.color = "#00aaff";
        logo.style.color = "#00aaff";
        document.querySelector('meta[name="theme-color"]').setAttribute('content',  '#fff');
        menu_device.style.backgroundColor = "#fff";
        for(let i = 0; i < menuBtns.length; i++){
            changeColor(menuBtns[i], i + "00", "#00aaff");
        }

        for(let i = 0; i < menuToggleLi.length; i++){
            changeColor(menuToggleLi[i], i + "00", "#00aaff");
        }
        
    } else {
        header.style.backgroundColor = "#00aaff";
        iconx.style.color = "#fff";
        menu_device.style.backgroundColor = "#00aaff";
        logo.style.color = "#fff";
        document.querySelector('meta[name="theme-color"]').setAttribute('content',  '#00aaff');
        for(let i = 0; i < menuBtns.length; i++){
            changeColor(menuBtns[i], i + "00", "#fff");
        }

        for(let i = 0; i < menuToggleLi.length; i++){
            changeColor(menuToggleLi[i], i + "00", "#fff");
        }
    }
});

function changeColor(item, time, color){
        setTimeout(function(){
        item.style.color = color;
    }, time);
    
}
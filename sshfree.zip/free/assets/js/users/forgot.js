const form = document.getElementById("send");
const form_code = document.getElementById("code");
const form_reset = document.getElementById("change");
const btn_code = document.getElementById("btn_code");
const btn_change = document.getElementById("btn_change");

const input_uid = document.querySelector(".uid");
const input_uid2 = document.querySelector(".uid2");
const input_code = document.querySelector(".code");

const btn = document.querySelector(".btn");
const h1 = document.querySelector("h1");
const h4 = document.querySelector("h4");

form.addEventListener("submit",(event) => {
    event.preventDefault();
    $.ajax({
        url: "/change",
        method: "POST",
        dataType: "json",
        data: $("#send").serialize(),
        beforeSend: function(){
            btn.style = "background-color: #fff; width: 50px; height: 50px; border-radius: 25px; border: 2px solid #f5f5f5; border-top-color: #00aaff;";
            btn.setAttribute("disabled", "disabled");
            setTimeout(function() {
            btn.style = "background-color: #fff; width: 50px; height: 50px; border-radius: 25px; border: 2px solid #f5f5f5; border-top-color: #00aaff; animation: rotation 2s infinite ease;";
            }, 300);
        },
        success: function(callback){
            btn.setAttribute("disabled", "disabled");
            if(callback.type == "success"){
                btn.style = "width: 50px; height: 50px; border-radius: 25px;";
                btn.innerHTML = "<i class='fa fa-check'></i>";
                form.style.opacity = "0";
                setTimeout(function() {
                    form.remove();
                    form_code.style.display = "flex";
                    form_code.style.opacity = "1";
                }, 1000);
                h1.innerHTML = "Digite o código que você recebeu.";
                h4.innerHTML = "Verifique também a sua caixa de spam.";
                input_uid.value = callback.uid;
                input_uid2.value = callback.uid;
            } else if(callback.type == "error") {
                btn.style = "background-color: #ff0000; border: 1px solid #ee0000; width: 50px; height: 50px; border-radius: 25px;";
                btn.innerHTML = "<i class='fa fa-times'></i>";
            }
            setTimeout(function() {
                btn.style = "";
                btn.innerHTML = "Enviar";
                btn.removeAttribute("disabled");
            }, 3000)
            
        }
    })
});

form_code.addEventListener("submit", function(e) {
    e.preventDefault();
    $.ajax({
        url: "/checkCode",
        method: "POST",
        dataType: "json",
        data: $("#code").serialize(),
        beforeSend: function(){
            btn_code.style = "background-color: #fff; width: 50px; height: 50px; border-radius: 25px; border: 2px solid #f5f5f5; border-top-color: #00aaff;";
            btn_code.setAttribute("disabled", "disabled");
            setTimeout(function() {
                btn_code.style = "background-color: #fff; width: 50px; height: 50px; border-radius: 25px; border: 2px solid #f5f5f5; border-top-color: #00aaff; animation: rotation 2s infinite ease;";
            }, 300);
        },
        success: function(callback){
            if(callback.type == "success"){
                input_code.value = callback.code;
                btn_code.style = "width: 50px; height: 50px; border-radius: 25px;";
                btn_code.innerHTML = "<i class='fa fa-check'></i>";
                form_code.style.opacity = "0";
                setTimeout(function() {
                    form_code.remove();
                    form_reset.style.display = "flex";
                    form_reset.style.opacity = "1";
                }, 1000);
                h1.innerHTML = "Digite a sua nova senha.";
                h4.innerHTML = "Digite a mesma nos dois campos abaixo.";
            } else {
                btn_code.style = "background-color: #ff0000; border: 1px solid #ee0000; width: 50px; height: 50px; border-radius: 25px;";
                btn_code.innerHTML = "<i class='fa fa-times'></i>";
            }
            setTimeout(function() {
                btn_code.style = "";
                btn_code.innerHTML = "Checar";
                btn_code.removeAttribute("disabled");
            }, 3000)
        }
    })
});

form_reset.addEventListener("submit", function(e) {
    e.preventDefault();
    $.ajax({
        url: "/alterarSenha",
        method: "POST",
        dataType: "json",
        data: $("#change").serialize(),
        beforeSend: function(){
            btn_change.style = "background-color: #fff; width: 50px; height: 50px; border-radius: 25px; border: 2px solid #f5f5f5; border-top-color: #00aaff;";
            btn_change.setAttribute("disabled", "disabled");
            setTimeout(function() {
                btn_change.style = "background-color: #fff; width: 50px; height: 50px; border-radius: 25px; border: 2px solid #f5f5f5; border-top-color: #00aaff; animation: rotation 2s infinite ease;";
            }, 300);
        },
        success: function(callback){
            if(callback.type == "success"){
                h1.innerHTML = "Senha alterada com sucesso!";
                h4.remove();
                btn_change.style = "width: 50px; height: 50px; border-radius: 25px;";
                btn_change.innerHTML = "<i class='fa fa-check'></i>";
                setTimeout(function() {
                     window.location.href = "https://sshshop.xyz/login";
                }, 1000)
               
            } else {
                alert(callback.message);
                btn_change.style = "";
                btn_change.innerHTML = "Alterar";
                btn_change.removeAttribute("disabled");
            }
        }
    })
})
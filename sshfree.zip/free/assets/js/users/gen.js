const form = document.querySelector("form");
const btn = document.querySelector(".btn");
const res = document.getElementById("res");


form.addEventListener("submit", (event) => {
    event.preventDefault();
    
    $.ajax({
        url: "/gerar",
        method: "POST",
        dataType: "json",
        data: $("form").serialize(),
        beforeSend: function(){
            btn.innerHTML = "<i class=\"fas fa-circle-notch fa-spin\"></i>";
        },
        success: function(callback){

            if(callback.type === 'error'){
            res.style.top = 0;
            res.innerHTML = "<h1>Erro</h1><p>"+ callback.message +"</p>";
            time = setTimeout(function(){
                res.style.top = "-100%";
            }, 2200)
            btn.innerHTML = "Criar";
            } else {
                res.style.top = 0;
                res.innerHTML = "<h1>Sucesso!</h1><p>IP: "+ callback.dados.ip +"</p><p>Portas: "+ callback.dados.portas +"</p><p>Usuário: "+ callback.dados.user +"</p><p>Senha: "+ callback.dados.pass +"</p><br><button class='copy_btn' onclick='copySsh()'><i class=\"far fa-copy\"></i></button>";
                document.getElementById("ssh_acc_copy").innerText = "IP: "+ callback.dados.ip +"\nPortas: "+ callback.dados.portas +"\nUsuário: "+ callback.dados.user +"\nSenha: "+ callback.dados.pass;
                document.getElementById("ssh_acc_copy").value = "IP: "+ callback.dados.ip +"\nPortas: "+ callback.dados.portas +"\nUsuário: "+ callback.dados.user +"\nSenha: "+ callback.dados.pass;
                btn.innerHTML = "Criar";
            }
            
        }
    })
})


function copySsh(){
    document.getElementById("ssh_acc_copy").select();
    const btn_copy = document.querySelector(".copy_btn");
    document.execCommand('copy');
    btn_copy.style = "background-color: #00aaff; border: 1px solid #888; border-top-color: #fff; animation: rotation 1.5s infinite ease;";
    setTimeout(function() {
        btn_copy.style = "";
        btn_copy.innerHTML = "<i class=\"fa fa-check\"></i>";
    }, 2000);
    setTimeout(function() {
        res.style.top = "-100%";
    }, 5000);
}


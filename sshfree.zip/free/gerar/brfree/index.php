<?php
require __DIR__ . "/vendor/autoload.php";
session_start();
$_SESSION["time"] = strtotime("now");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/style.css">
    <title><?= SITE["name"];?></title>
</head>
<body>
    <header>
        <div class="logo"><?= SITE["name"];?></div>
        <div class="menu">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </header>
    <div class="menu_tab">
        <ul>
<li><a href="http://nettunnel.xyz/app-clientes/">✡Apk Ptemium</a></li>
<li><a href="https://net-tunnel-vpn.sshshop.xyz/">✡Login Premium</a></li>
<li><a href="http://nettunnel.xyz/revenda.html">✡Revender Login</a></li>

            <li><a href="http://t.me/GRUPONETTUNNEL_OFICIAL">✡Grupo Telegram</a></li>
            <li><a href="http://t.me/CANALNETTUNNEL_OFICIAL">✡Canal Telegram</a></li>
            <li><a href="http://t.me/NetTunnel">✡Contato</a></li>
        </ul>
    </div>
<div class="content">
        <h1>Gerar conta grátis</h1>
        <div class="server">
            <ul>
                <li>Endereço IP: <?= SERVER["ip"];?></li>
                <li>Localização: <?= SERVER["local"];?></li>
                <li>Validade: <?= SERVER["days"] != 1 ? SERVER["days"] . " dias" : "1 dia";?></li>
                <li>Limite: <?= SERVER["user_per_account"];?></li>
                <li>Contas por dia: <?= SERVER["limit"];?></li>
            </ul>
                <button class="btn">Gerar</button>
        </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="./js/script.js"></script>
</body>
</html>

<?php

/*
 * ARQUIVO DE CONFIGURAÇAO DO SITE.
 * leia o manual de edição.
 */

define('SITE', [
    "name" => "BR FREE",
    "url" => "http://nettunnel.xyz/free/gerar/brfree/"
]);

define('SERVER', [
    "ip" => "159.203.32.146",
    "user" => "root",
    "pass" => "luiznet",
    "days" => 4,
    "local" => "São Paulo - Brasil",
    "user_per_account" => 1, //Limite de conexões por usuário
    "limit" => 400 //Limite de contas por dia, por enquanto n muda nada, pq não ta conectado com o banco de dados.
]);

define('TELEGRAM', [
    "group" => "Link do grupo",
    "channel" => "Link do canal",
    "my_user" => "Seu link de usuário"
]);

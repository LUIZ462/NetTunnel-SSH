<?php
session_start();
require __DIR__ . "/../vendor/autoload.php";
use phpseclib\Net\SSH2;
$ssh = new SSH2(SERVER['ip']);
if (!$ssh->login(SERVER['user'], SERVER['pass'])) {
    exit('Erro ao autenticar');
}
if(!isset($_SESSION["time"])){
    $callback = [
        "message" => "Erro ao gerar conta.",
        "ip" => SERVER['ip'],
        "local" => SERVER['local'],
        "valid" => SERVER['ip'],
        "limit" => SERVER['user_per_account'],
        "acc" => SERVER['limit'],
        "type" => "error"
    ];
    echo json_encode($callback);
    return;
}
$letters = str_shuffle("abcdefghijklmnopkrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
$user = substr($letters, 0, 6);
$pass = rand(000000, 999999);
$resp = $ssh->exec('cd /etc/SSHShop; ./criarusuario.sh ' . $user . ' ' . $pass . ' ' . SERVER['days'] . ' ' . SERVER['user_per_account']);

if(preg_replace('/\D/', '', $resp) == 13){
    $callback = [
        "user" => $user,
        "pass" => $pass,
        "ip" => SERVER['ip'],
        "message" => "Conta gerada com sucesso.",
        "type" => "success"
    ];
    echo json_encode($callback);
    session_destroy();
} else {
    $callback = [
        "message" => "Erro ao gerar conta.",
        "ip" => SERVER['ip'],
        "local" => SERVER['local'],
        "valid" => SERVER['ip'],
        "limit" => SERVER['user_per_account'],
        "acc" => SERVER['limit'],
        "type" => "error"
    ];
}

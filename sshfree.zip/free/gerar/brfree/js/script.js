const btn = document.querySelector(".btn");
const content = document.querySelector(".content");
const menu = document.querySelector(".menu");
const menu_tab = document.querySelector(".menu_tab");

btn.addEventListener("click", (e) => {
    e.preventDefault();

    $.ajax({
        url: "pages/create.php",
        dataType: "json",
        type: "POST",
        beforeSend: function(){
            content.style = "width: 40px; height: 40px; border-radius: 50%; top: 50%; background: transparent; border: 1px solid #333; border-top-color: #00aaff; animation: rotate .2s infinite; animation-timing-function: linear;"; 
            content.innerHTML = "";
        },
        success: function(callback){
            content.style = "";
             if(callback.type == "success"){
                content.innerHTML = '<h1>'+ callback.message +'</h1><div class="server"><ul><li>Endereço IP: '+ callback.ip +'</li><li>Usuário: '+ callback.user +'</li><li>Senha: '+ callback.pass +'</li></ul></div>';
            } else {
                content.innerHTML = '<h1>'+ callback.message +'</h1><div class="server"><ul><li>Endereço IP: '+ callback.ip +'</li><li>Localização: '+ callback.local +' </li><li>Validade: '+ callback.valid +' </li><li>Limite: '+ callback.limit +'</li><li>Contas por dia: '+ callback.acc +'</li></ul><button class="btn">Gerar</button></div>';
            }
        }
    });
});


menu.addEventListener("click", () => {
    if(open){
        menu_tab.style.right = "0";
        open = null;
    } else {
        menu_tab.style.right = "-100%";
        open = 1;
    }
    
})